"""Top-level package for SIMO.io."""

__author__ = """Simanas Venckauskas"""
__email__ = 'simo@simo.io'
__version__ = '1.5.9'
