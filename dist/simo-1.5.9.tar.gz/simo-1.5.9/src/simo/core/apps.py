import sys
import pytz
from django.utils import timezone
from django.apps import AppConfig


class CoreAppConfig(AppConfig):
    name = 'simo.core'
