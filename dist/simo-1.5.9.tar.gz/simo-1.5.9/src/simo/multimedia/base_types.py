from django.utils.translation import gettext_lazy as _

BASE_TYPES = {
    'audio-player': _("Audio Player"),
    'video-player': _("Video Player"),
}
