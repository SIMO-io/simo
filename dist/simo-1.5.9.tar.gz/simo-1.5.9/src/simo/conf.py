from dynamic_preferences.registries import global_preferences_registry as gpr

dynamic_settings = gpr.manager()
